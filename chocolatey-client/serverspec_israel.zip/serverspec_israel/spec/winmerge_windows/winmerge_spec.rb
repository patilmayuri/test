require 'spec_helper_local'

describe file('C:\Program Files\WinMerge') do
  it { should exist}
  it { should be_directory}
end

describe windows_registry_key('HKEY_CURRENT_USER\SOFTWARE\Thingamahoochie\WinMerge') do
  it { should exist }
  it { should have_property_value('Executable', String, 'C:\Program Files\WinMerge\WinMergeU.exe') }
end